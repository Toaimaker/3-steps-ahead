---
fonte: Untapped.gg API pubbliche, Quick Draft e Premier HOB, ultimi 90 giorni; scaricato il 05/11/2026 22:24; rigenerato da Companion/Drafter/quick_draft_untapped.py
---

# Il Quick Draft di HOB visto da Untapped

17Lands pubblica solo il Premier (umani); noi giochiamo il Quick (bot). Qui il formato vero.

## 1. Le coppie: Quick contro Premier

| Coppia | Quick: partite vinte | partite | Premier: posto | Premier: vinte |
| :--- | ---: | ---: | ---: | ---: |
| WU | **54.4%** | 33,722 | 5 | 52.4% |
| BG | **54.3%** | 32,126 | 2 | 53.9% |
| BR | **53.7%** | 41,533 | 1 | 54.6% |
| UR | **53.3%** | 1,607 | 6 | 52.0% |
| WR | **53.1%** | 28,279 | 3 | 53.3% |
| UB | **52.5%** | 2,810 | 7 | 51.5% |
| UG | **51.4%** | 13,893 | 9 | 49.5% |
| WB | **51.0%** | 1,240 | 4 | 53.2% |
| WG | **50.3%** | 924 | 10 | 47.4% |
| RG | **50.3%** | 1,350 | 8 | 51.3% |

Errore tipico su 2.000-5.000 partite: ±1-1,5 punti. La classifica del Premier non vale per il Quick, e nessuna delle due si usa come bonus sulle carte (regola permanente del 10 ott 2026): al massimo uno spareggio.

## 2. Come sono fatti i mazzi da 7 vittorie (442 con la lista, su 2599 trofei)

Colori (3+ carte per colore): UG 59, WU 54, WR 46, BR 46, BG 43, UBG 27, WUR 26, WUG 20, UB 12, BRG 12

| Voce | Mediana | 10°-90° percentile | Modello del 9 ott |
| :--- | ---: | ---: | :--- |
| creature | **15.0** | 12.0-18.0 | 15-17 |
| creature da 1-2 | **6.0** | 4.0-9.0 | ≥5 (6-8) |
| creature da 5+ | **2.0** | 0.0-5.0 | ≤2 |
| costo medio creature | **3.1** | 2.6-3.7 | ≤2,9 |
| rimozioni vere | **5.0** | 2.0-7.0 | 5-7 |
| rimozioni grosse | **4.0** | 2.0-7.0 | ≥3 |
| stazza (forza 3+ o costituzione 4+) | **6.5** | 3.0-10.0 | ≥4 |
| pressione al T4 | **6.5** | 4.5-8.8 | ≥6 |
| altre (pescate, trucchi, planeswalker) | **4.0** | 1.0-7.0 | ≤3 |
| minacce (volanti 3+ o 5/5+) | **1.0** | 0.0-2.0 | ≥3 |
| terre | **17.0** | 16.0-17.0 | 16-17 |

**Contro-caso:** sono solo mazzi vincenti, senza i perdenti accanto. Dicono cosa basta per arrivare a 7 nel Quick, non cosa causa la vittoria. Il modello del 9 ott viene dal Premier di 6 set con i perdenti dentro.
