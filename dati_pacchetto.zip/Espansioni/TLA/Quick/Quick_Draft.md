---
fonte: Untapped.gg API pubbliche, Quick Draft e Premier TLA, ultimi 90 giorni; scaricato il 05/11/2026 18:40; rigenerato da Companion/Drafter/quick_draft_untapped.py
---

# Il Quick Draft di TLA visto da Untapped

17Lands pubblica solo il Premier (umani); noi giochiamo il Quick (bot). Qui il formato vero.

## 1. Le coppie: Quick contro Premier

| Coppia | Quick: partite vinte | partite | Premier: posto | Premier: vinte |
| :--- | ---: | ---: | ---: | ---: |
| WR | **55.8%** | 26,112 | 4 | 55.1% |
| UR | **54.5%** | 22,131 | 7 | 54.4% |
| RG | **54.5%** | 18,272 | 3 | 55.1% |
| WG | **54.3%** | 28,231 | 5 | 54.7% |
| BG | **54.1%** | 21,669 | 8 | 52.4% |
| WU | **54.0%** | 38,981 | 6 | 54.4% |
| UB | **53.6%** | 26,810 | 2 | 56.3% |
| WB | **53.5%** | 22,791 | 1 | 58.2% |
| BR | **53.4%** | 19,542 | 9 | 52.4% |
| UG | **52.6%** | 11,817 | 10 | 51.8% |

Errore tipico su 2.000-5.000 partite: ±1-1,5 punti. La classifica del Premier non vale per il Quick, e nessuna delle due si usa come bonus sulle carte (regola permanente del 10 ott 2026): al massimo uno spareggio.

## 2. Come sono fatti i mazzi da 7 vittorie (993 con la lista, su 5469 trofei)

Colori (3+ carte per colore): UB 58, WB 53, RG 49, WG 48, BR 48, BG 46, WR 45, URG 45, UR 45, WUB 43

| Voce | Mediana | 10°-90° percentile | Modello del 9 ott |
| :--- | ---: | ---: | :--- |
| creature | **14.0** | 11.0-17.0 | 15-17 |
| creature da 1-2 | **5.0** | 2.0-7.0 | ≥5 (6-8) |
| creature da 5+ | **3.0** | 1.0-5.0 | ≤2 |
| costo medio creature | **3.3** | 2.8-3.8 | ≤2,9 |
| rimozioni vere | **4.0** | 1.0-6.0 | 5-7 |
| rimozioni grosse | **3.0** | 1.0-5.0 | ≥3 |
| stazza (forza 3+ o costituzione 4+) | **6.0** | 3.0-9.0 | ≥4 |
| pressione al T4 | **5.2** | 3.5-7.5 | ≥6 |
| altre (pescate, trucchi, planeswalker) | **6.0** | 3.0-10.0 | ≤3 |
| minacce (volanti 3+ o 5/5+) | **1.0** | 0.0-3.0 | ≥3 |
| terre | **17.0** | 16.0-17.0 | 16-17 |

**Contro-caso:** sono solo mazzi vincenti, senza i perdenti accanto. Dicono cosa basta per arrivare a 7 nel Quick, non cosa causa la vittoria. Il modello del 9 ott viene dal Premier di 6 set con i perdenti dentro.
