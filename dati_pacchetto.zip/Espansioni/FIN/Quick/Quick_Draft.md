---
fonte: Untapped.gg API pubbliche, Quick Draft e Premier FIN, ultimi 90 giorni; scaricato il 05/11/2026 23:03; rigenerato da Companion/Drafter/quick_draft_untapped.py
---

# Il Quick Draft di FIN visto da Untapped

17Lands pubblica solo il Premier (umani); noi giochiamo il Quick (bot). Qui il formato vero.

## 1. Le coppie: Quick contro Premier

| Coppia | Quick: partite vinte | partite | Premier: posto | Premier: vinte |
| :--- | ---: | ---: | ---: | ---: |
| UR | **56.7%** | 50,187 | 1 | 56.2% |
| WB | **54.1%** | 16,715 | 5 | 54.5% |
| WG | **54.1%** | 10,859 | 3 | 55.0% |
| BG | **53.7%** | 18,815 | 2 | 55.7% |
| RG | **53.6%** | 14,854 | 10 | 52.3% |
| BR | **53.3%** | 19,526 | 7 | 54.1% |
| UB | **53.3%** | 15,890 | 4 | 55.0% |
| UG | **53.2%** | 11,226 | 9 | 53.7% |
| WR | **52.8%** | 13,993 | 6 | 54.2% |
| WU | **51.3%** | 14,028 | 8 | 54.0% |

Errore tipico su 2.000-5.000 partite: ±1-1,5 punti. La classifica del Premier non vale per il Quick, e nessuna delle due si usa come bonus sulle carte (regola permanente del 10 ott 2026): al massimo uno spareggio.

## 2. Come sono fatti i mazzi da 7 vittorie (715 con la lista, su 3193 trofei)

Colori (3+ carte per colore): WB 56, BG 48, UB 48, WU 48, WR 47, UR 44, UBR 43, RG 43, BR 42, UBG 41

| Voce | Mediana | 10°-90° percentile | Modello del 9 ott |
| :--- | ---: | ---: | :--- |
| creature | **12.0** | 9.0-15.0 | 15-17 |
| creature da 1-2 | **4.0** | 2.0-7.0 | ≥5 (6-8) |
| creature da 5+ | **3.0** | 0.0-5.0 | ≤2 |
| costo medio creature | **3.3** | 2.6-4.0 | ≤2,9 |
| rimozioni vere | **3.0** | 1.0-7.0 | 5-7 |
| rimozioni grosse | **3.0** | 1.0-5.0 | ≥3 |
| stazza (forza 3+ o costituzione 4+) | **6.0** | 3.0-10.0 | ≥4 |
| pressione al T4 | **4.5** | 2.8-6.5 | ≥6 |
| altre (pescate, trucchi, planeswalker) | **8.0** | 5.0-12.0 | ≤3 |
| minacce (volanti 3+ o 5/5+) | **1.0** | 0.0-2.0 | ≥3 |
| terre | **17.0** | 16.0-17.0 | 16-17 |

**Contro-caso:** sono solo mazzi vincenti, senza i perdenti accanto. Dicono cosa basta per arrivare a 7 nel Quick, non cosa causa la vittoria. Il modello del 9 ott viene dal Premier di 6 set con i perdenti dentro.
