---
fonte: Untapped.gg API pubbliche, Quick Draft e Premier FRA, ultimi 90 giorni; scaricato il 09/11/2026 16:29; rigenerato da Companion/Drafter/quick_draft_untapped.py
---

# Il Quick Draft di FRA visto da Untapped

17Lands pubblica solo il Premier (umani); noi giochiamo il Quick (bot). Qui il formato vero.

## 1. Le coppie: Quick contro Premier

| Coppia | Quick: partite vinte | partite | Premier: posto | Premier: vinte |
| :--- | ---: | ---: | ---: | ---: |
| UB | **54.4%** | 20,132 | 2 | 53.5% |
| BR | **54.3%** | 15,916 | 7 | 52.4% |
| UR | **54.2%** | 19,337 | 3 | 53.2% |
| WU | **53.9%** | 19,700 | 1 | 54.0% |
| BG | **53.6%** | 7,674 | 4 | 52.9% |
| WG | **53.3%** | 23,042 | 8 | 52.4% |
| RG | **53.2%** | 14,678 | 5 | 52.8% |
| WB | **53.0%** | 6,992 | 6 | 52.6% |
| UG | **52.4%** | 6,171 | 10 | 51.2% |
| WR | **51.2%** | 5,951 | 9 | 51.4% |

Errore tipico su 2.000-5.000 partite: ±1-1,5 punti. La classifica del Premier non vale per il Quick, e nessuna delle due si usa come bonus sulle carte (regola permanente del 10 ott 2026): al massimo uno spareggio.

## 2. Come sono fatti i mazzi da 7 vittorie (799 con la lista, su 3057 trofei)

Colori (3+ carte per colore): WBG 50, UB 48, BR 48, RG 47, WU 46, BRG 44, UBR 42, UR 42, WB 40, WUB 40

| Voce | Mediana | 10°-90° percentile | Modello del 9 ott |
| :--- | ---: | ---: | :--- |
| creature | **14.0** | 10.0-17.0 | 15-17 |
| creature da 1-2 | **5.0** | 2.0-8.0 | ≥5 (6-8) |
| creature da 5+ | **3.0** | 1.0-6.0 | ≤2 |
| costo medio creature | **3.4** | 2.8-4.0 | ≤2,9 |
| rimozioni vere | **6.0** | 3.0-9.0 | 5-7 |
| rimozioni grosse | **5.0** | 2.0-7.0 | ≥3 |
| stazza (forza 3+ o costituzione 4+) | **7.0** | 4.0-10.0 | ≥4 |
| pressione al T4 | **5.2** | 3.2-7.5 | ≥6 |
| altre (pescate, trucchi, planeswalker) | **5.0** | 2.0-8.0 | ≤3 |
| minacce (volanti 3+ o 5/5+) | **1.0** | 0.0-2.0 | ≥3 |
| terre | **17.0** | 16.0-17.0 | 16-17 |

**Contro-caso:** sono solo mazzi vincenti, senza i perdenti accanto. Dicono cosa basta per arrivare a 7 nel Quick, non cosa causa la vittoria. Il modello del 9 ott viene dal Premier di 6 set con i perdenti dentro.
