---
fonte: Untapped.gg API pubbliche, Quick Draft e Premier EOE, ultimi 90 giorni; scaricato il 05/11/2026 18:33; rigenerato da Companion/Drafter/quick_draft_untapped.py
---

# Il Quick Draft di EOE visto da Untapped

17Lands pubblica solo il Premier (umani); noi giochiamo il Quick (bot). Qui il formato vero.

## 1. Le coppie: Quick contro Premier

| Coppia | Quick: partite vinte | partite | Premier: posto | Premier: vinte |
| :--- | ---: | ---: | ---: | ---: |
| RG | **54.7%** | 13,615 | 4 | 54.3% |
| UG | **54.4%** | 18,727 | 5 | 54.1% |
| WB | **53.8%** | 27,155 | 2 | 54.8% |
| BR | **53.7%** | 19,942 | 1 | 56.9% |
| UB | **53.5%** | 20,117 | 3 | 54.7% |
| WG | **53.5%** | 18,273 | 7 | 52.5% |
| UR | **53.3%** | 14,411 | 8 | 52.1% |
| WU | **52.9%** | 24,199 | 10 | 51.7% |
| BG | **52.5%** | 9,516 | 6 | 53.8% |
| WR | **52.2%** | 8,279 | 9 | 51.8% |

Errore tipico su 2.000-5.000 partite: ±1-1,5 punti. La classifica del Premier non vale per il Quick, e nessuna delle due si usa come bonus sulle carte (regola permanente del 10 ott 2026): al massimo uno spareggio.

## 2. Come sono fatti i mazzi da 7 vittorie (664 con la lista, su 2880 trofei)

Colori (3+ carte per colore): WU 55, UB 49, WG 47, BR 47, RG 46, UG 44, WB 44, WR 42, UR 41, BG 39

| Voce | Mediana | 10°-90° percentile | Modello del 9 ott |
| :--- | ---: | ---: | :--- |
| creature | **14.0** | 11.0-17.0 | 15-17 |
| creature da 1-2 | **5.0** | 3.0-8.0 | ≥5 (6-8) |
| creature da 5+ | **3.0** | 1.0-5.0 | ≤2 |
| costo medio creature | **3.3** | 2.7-3.9 | ≤2,9 |
| rimozioni vere | **4.0** | 1.0-7.0 | 5-7 |
| rimozioni grosse | **3.0** | 1.0-5.0 | ≥3 |
| stazza (forza 3+ o costituzione 4+) | **7.0** | 4.0-9.0 | ≥4 |
| pressione al T4 | **5.5** | 3.5-7.2 | ≥6 |
| altre (pescate, trucchi, planeswalker) | **6.0** | 3.0-9.0 | ≤3 |
| minacce (volanti 3+ o 5/5+) | **1.0** | 0.0-2.0 | ≥3 |
| terre | **17.0** | 16.0-17.0 | 16-17 |

**Contro-caso:** sono solo mazzi vincenti, senza i perdenti accanto. Dicono cosa basta per arrivare a 7 nel Quick, non cosa causa la vittoria. Il modello del 9 ott viene dal Premier di 6 set con i perdenti dentro.
