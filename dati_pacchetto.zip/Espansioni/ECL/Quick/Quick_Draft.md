---
fonte: Untapped.gg API pubbliche, Quick Draft e Premier ECL, ultimi 90 giorni; scaricato il 05/11/2026 18:26; rigenerato da Companion/Drafter/quick_draft_untapped.py
---

# Il Quick Draft di ECL visto da Untapped

17Lands pubblica solo il Premier (umani); noi giochiamo il Quick (bot). Qui il formato vero.

## 1. Le coppie: Quick contro Premier

| Coppia | Quick: partite vinte | partite | Premier: posto | Premier: vinte |
| :--- | ---: | ---: | ---: | ---: |
| WU | **55.1%** | 17,663 | 3 | 53.9% |
| UR | **54.4%** | 15,060 | 4 | 53.5% |
| WG | **54.3%** | 12,950 | 2 | 54.0% |
| BG | **54.0%** | 20,450 | 1 | 54.1% |
| WR | **54.0%** | 2,629 | 7 | 50.2% |
| BR | **53.3%** | 12,707 | 5 | 51.2% |
| RG | **52.7%** | 1,843 | 6 | 50.6% |
| WB | **52.6%** | 3,685 | 8 | 49.1% |
| UB | **50.2%** | 1,782 | 10 | 48.4% |
| UG | **47.8%** | 925 | 9 | 49.0% |

Errore tipico su 2.000-5.000 partite: ±1-1,5 punti. La classifica del Premier non vale per il Quick, e nessuna delle due si usa come bonus sulle carte (regola permanente del 10 ott 2026): al massimo uno spareggio.

## 2. Come sono fatti i mazzi da 7 vittorie (881 con la lista, su 1649 trofei)

Colori (3+ carte per colore): WG 107, UR 106, WU 105, BG 103, BR 100, WBG 43, WB 39, WRG 28, URG 27, WBR 25

| Voce | Mediana | 10°-90° percentile | Modello del 9 ott |
| :--- | ---: | ---: | :--- |
| creature | **16.0** | 13.0-19.0 | 15-17 |
| creature da 1-2 | **5.0** | 3.0-8.0 | ≥5 (6-8) |
| creature da 5+ | **3.0** | 1.0-6.0 | ≤2 |
| costo medio creature | **3.3** | 2.9-3.9 | ≤2,9 |
| rimozioni vere | **4.0** | 1.0-7.0 | 5-7 |
| rimozioni grosse | **3.0** | 1.0-5.0 | ≥3 |
| stazza (forza 3+ o costituzione 4+) | **9.0** | 6.0-13.0 | ≥4 |
| pressione al T4 | **7.2** | 5.0-10.2 | ≥6 |
| altre (pescate, trucchi, planeswalker) | **4.0** | 1.0-7.0 | ≤3 |
| minacce (volanti 3+ o 5/5+) | **1.0** | 0.0-2.0 | ≥3 |
| terre | **17.0** | 16.0-17.0 | 16-17 |

**Contro-caso:** sono solo mazzi vincenti, senza i perdenti accanto. Dicono cosa basta per arrivare a 7 nel Quick, non cosa causa la vittoria. Il modello del 9 ott viene dal Premier di 6 set con i perdenti dentro.
