---
fonte: Untapped.gg API pubbliche, Quick Draft e Premier SOS, ultimi 90 giorni; scaricato il 05/11/2026 17:56; rigenerato da Companion/Drafter/quick_draft_untapped.py
---

# Il Quick Draft di SOS visto da Untapped

17Lands pubblica solo il Premier (umani); noi giochiamo il Quick (bot). Qui il formato vero.

## 1. Le coppie: Quick contro Premier

| Coppia | Quick: partite vinte | partite | Premier: posto | Premier: vinte |
| :--- | ---: | ---: | ---: | ---: |
| WG | **55.4%** | 83 | - | 0.0% |
| WB | **55.2%** | 21,028 | 1 | 55.2% |
| BG | **55.1%** | 29,228 | 3 | 53.0% |
| UG | **53.4%** | 11,760 | 4 | 52.6% |
| UB | **53.3%** | 336 | 7 | 46.1% |
| WR | **51.9%** | 11,044 | 2 | 54.5% |
| UR | **51.3%** | 18,407 | 6 | 51.5% |
| BR | **49.1%** | 222 | - | 0.0% |
| WU | **44.4%** | 162 | - | 0.0% |

Errore tipico su 2.000-5.000 partite: ±1-1,5 punti. La classifica del Premier non vale per il Quick, e nessuna delle due si usa come bonus sulle carte (regola permanente del 10 ott 2026): al massimo uno spareggio.

## 2. Come sono fatti i mazzi da 7 vittorie (818 con la lista, su 1919 trofei)

Colori (3+ carte per colore): BG 144, WB 142, UG 111, UR 107, WR 104, URG 86, UBG 55, WBG 14, UBRG 13, WUR 12

| Voce | Mediana | 10°-90° percentile | Modello del 9 ott |
| :--- | ---: | ---: | :--- |
| creature | **13.0** | 9.0-16.0 | 15-17 |
| creature da 1-2 | **5.0** | 3.0-8.0 | ≥5 (6-8) |
| creature da 5+ | **1.0** | 0.0-3.0 | ≤2 |
| costo medio creature | **3.0** | 2.5-3.4 | ≤2,9 |
| rimozioni vere | **4.0** | 1.0-7.0 | 5-7 |
| rimozioni grosse | **3.0** | 1.0-5.0 | ≥3 |
| stazza (forza 3+ o costituzione 4+) | **6.0** | 3.0-9.0 | ≥4 |
| pressione al T4 | **6.2** | 3.2-9.0 | ≥6 |
| altre (pescate, trucchi, planeswalker) | **7.0** | 3.0-11.0 | ≤3 |
| minacce (volanti 3+ o 5/5+) | **1.0** | 0.0-2.0 | ≥3 |
| terre | **17.0** | 16.0-17.0 | 16-17 |

**Contro-caso:** sono solo mazzi vincenti, senza i perdenti accanto. Dicono cosa basta per arrivare a 7 nel Quick, non cosa causa la vittoria. Il modello del 9 ott viene dal Premier di 6 set con i perdenti dentro.
