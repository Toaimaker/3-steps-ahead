---
fonte: Untapped.gg API pubbliche, Quick Draft e Premier TMT, ultimi 90 giorni; scaricato il 05/11/2026 22:18; rigenerato da Companion/Drafter/quick_draft_untapped.py
---

# Il Quick Draft di TMT visto da Untapped

17Lands pubblica solo il Premier (umani); noi giochiamo il Quick (bot). Qui il formato vero.

## 1. Le coppie: Quick contro Premier

| Coppia | Quick: partite vinte | partite | Premier: posto | Premier: vinte |
| :--- | ---: | ---: | ---: | ---: |
| UR | **55.5%** | 28,880 | 2 | 54.8% |
| BG | **54.5%** | 19,920 | 4 | 53.0% |
| WB | **54.4%** | 28,518 | 1 | 55.6% |
| WG | **54.2%** | 2,664 | 5 | 52.4% |
| WR | **53.3%** | 13,514 | 3 | 53.1% |
| UG | **53.1%** | 17,311 | 7 | 51.3% |
| WU | **51.9%** | 1,321 | 6 | 52.0% |
| UB | **47.4%** | 1,176 | 8 | 49.0% |
| RG | **47.1%** | 1,298 | 9 | 46.0% |
| BR | **47.0%** | 893 | 10 | 44.3% |

Errore tipico su 2.000-5.000 partite: ±1-1,5 punti. La classifica del Premier non vale per il Quick, e nessuna delle due si usa come bonus sulle carte (regola permanente del 10 ott 2026): al massimo uno spareggio.

## 2. Come sono fatti i mazzi da 7 vittorie (548 con la lista, su 2416 trofei)

Colori (3+ carte per colore): UR 56, UBG 53, WB 50, WR 48, URG 47, BG 43, UG 41, WBG 41, WG 29, WUG 24

| Voce | Mediana | 10°-90° percentile | Modello del 9 ott |
| :--- | ---: | ---: | :--- |
| creature | **15.0** | 11.0-18.0 | 15-17 |
| creature da 1-2 | **5.0** | 3.0-8.0 | ≥5 (6-8) |
| creature da 5+ | **3.0** | 1.0-5.0 | ≤2 |
| costo medio creature | **3.3** | 2.8-3.8 | ≤2,9 |
| rimozioni vere | **5.0** | 2.0-8.0 | 5-7 |
| rimozioni grosse | **3.0** | 1.0-6.0 | ≥3 |
| stazza (forza 3+ o costituzione 4+) | **7.0** | 4.0-10.0 | ≥4 |
| pressione al T4 | **5.8** | 3.8-7.8 | ≥6 |
| altre (pescate, trucchi, planeswalker) | **4.0** | 1.0-7.0 | ≤3 |
| minacce (volanti 3+ o 5/5+) | **1.0** | 0.0-3.0 | ≥3 |
| terre | **17.0** | 16.0-17.0 | 16-17 |

**Contro-caso:** sono solo mazzi vincenti, senza i perdenti accanto. Dicono cosa basta per arrivare a 7 nel Quick, non cosa causa la vittoria. Il modello del 9 ott viene dal Premier di 6 set con i perdenti dentro.
