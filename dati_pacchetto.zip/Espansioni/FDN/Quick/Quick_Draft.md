---
fonte: Untapped.gg API pubbliche, Quick Draft e Premier FDN, ultimi 90 giorni; scaricato il 05/11/2026 18:19; rigenerato da Companion/Drafter/quick_draft_untapped.py
---

# Il Quick Draft di FDN visto da Untapped

17Lands pubblica solo il Premier (umani); noi giochiamo il Quick (bot). Qui il formato vero.

## 1. Le coppie: Quick contro Premier

| Coppia | Quick: partite vinte | partite | Premier: posto | Premier: vinte |
| :--- | ---: | ---: | ---: | ---: |
| BR | **55.6%** | 18,817 | 3 | 56.4% |
| RG | **54.8%** | 14,937 | 1 | 58.4% |
| UB | **54.7%** | 27,220 | 7 | 55.6% |
| WB | **54.7%** | 21,087 | 4 | 56.4% |
| WU | **54.1%** | 21,815 | 5 | 55.8% |
| WG | **53.6%** | 15,502 | 6 | 55.7% |
| BG | **53.0%** | 15,588 | 10 | 52.1% |
| UG | **52.2%** | 19,908 | 8 | 52.6% |
| WR | **51.7%** | 9,205 | 2 | 57.6% |
| UR | **50.8%** | 14,580 | 9 | 52.6% |

Errore tipico su 2.000-5.000 partite: ±1-1,5 punti. La classifica del Premier non vale per il Quick, e nessuna delle due si usa come bonus sulle carte (regola permanente del 10 ott 2026): al massimo uno spareggio.

## 2. Come sono fatti i mazzi da 7 vittorie (624 con la lista, su 3415 trofei)

Colori (3+ carte per colore): BR 61, WB 52, UR 51, WU 51, G 48, BG 46, WR 46, UG 45, UB 43, RG 42

| Voce | Mediana | 10°-90° percentile | Modello del 9 ott |
| :--- | ---: | ---: | :--- |
| creature | **15.0** | 12.0-18.0 | 15-17 |
| creature da 1-2 | **6.0** | 3.0-8.0 | ≥5 (6-8) |
| creature da 5+ | **3.0** | 1.0-5.0 | ≤2 |
| costo medio creature | **3.2** | 2.7-3.7 | ≤2,9 |
| rimozioni vere | **3.0** | 1.0-6.0 | 5-7 |
| rimozioni grosse | **2.0** | 1.0-5.0 | ≥3 |
| stazza (forza 3+ o costituzione 4+) | **8.0** | 4.0-12.0 | ≥4 |
| pressione al T4 | **7.0** | 4.5-9.5 | ≥6 |
| altre (pescate, trucchi, planeswalker) | **5.0** | 2.0-9.0 | ≤3 |
| minacce (volanti 3+ o 5/5+) | **1.0** | 0.0-2.0 | ≥3 |
| terre | **17.0** | 16.0-17.0 | 16-17 |

**Contro-caso:** sono solo mazzi vincenti, senza i perdenti accanto. Dicono cosa basta per arrivare a 7 nel Quick, non cosa causa la vittoria. Il modello del 9 ott viene dal Premier di 6 set con i perdenti dentro.
