---
fonte: Untapped.gg API pubbliche, Quick Draft e Premier TDM, ultimi 90 giorni; scaricato il 05/11/2026 22:38; rigenerato da Companion/Drafter/quick_draft_untapped.py
---

# Il Quick Draft di TDM visto da Untapped

17Lands pubblica solo il Premier (umani); noi giochiamo il Quick (bot). Qui il formato vero.

## 1. Le coppie: Quick contro Premier

| Coppia | Quick: partite vinte | partite | Premier: posto | Premier: vinte |
| :--- | ---: | ---: | ---: | ---: |
| WR | **57.9%** | 14,948 | 1 | 57.6% |
| WU | **54.0%** | 1,274 | 8 | 49.1% |
| UG | **53.8%** | 5,849 | 2 | 55.6% |
| RG | **53.8%** | 340 | 3 | 54.9% |
| BG | **53.3%** | 2,098 | 6 | 52.7% |
| UR | **52.3%** | 1,689 | 9 | 48.0% |
| WB | **51.9%** | 3,403 | 7 | 51.6% |
| WG | **51.0%** | 649 | 5 | 53.2% |
| UB | **49.6%** | 413 | - | 0.0% |
| BR | **40.8%** | 240 | 4 | 54.2% |

Errore tipico su 2.000-5.000 partite: ±1-1,5 punti. La classifica del Premier non vale per il Quick, e nessuna delle due si usa come bonus sulle carte (regola permanente del 10 ott 2026): al massimo uno spareggio.

## 2. Come sono fatti i mazzi da 7 vittorie (848 con la lista, su 1270 trofei)

Colori (3+ carte per colore): WBR 160, URG 118, WUR 106, WR 101, WBG 87, UBG 71, WUBRG 57, WURG 28, WB 20, UBRG 19

| Voce | Mediana | 10°-90° percentile | Modello del 9 ott |
| :--- | ---: | ---: | :--- |
| creature | **15.0** | 12.0-18.0 | 15-17 |
| creature da 1-2 | **5.0** | 2.0-8.0 | ≥5 (6-8) |
| creature da 5+ | **4.0** | 2.0-7.0 | ≤2 |
| costo medio creature | **3.5** | 2.9-4.2 | ≤2,9 |
| rimozioni vere | **5.0** | 2.0-7.0 | 5-7 |
| rimozioni grosse | **4.0** | 2.0-6.0 | ≥3 |
| stazza (forza 3+ o costituzione 4+) | **8.0** | 5.0-11.0 | ≥4 |
| pressione al T4 | **5.5** | 2.8-7.8 | ≥6 |
| altre (pescate, trucchi, planeswalker) | **5.0** | 2.0-8.0 | ≤3 |
| minacce (volanti 3+ o 5/5+) | **1.0** | 0.0-2.0 | ≥3 |
| terre | **17.0** | 16.0-17.0 | 16-17 |

**Contro-caso:** sono solo mazzi vincenti, senza i perdenti accanto. Dicono cosa basta per arrivare a 7 nel Quick, non cosa causa la vittoria. Il modello del 9 ott viene dal Premier di 6 set con i perdenti dentro.
