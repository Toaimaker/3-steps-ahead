---
fonte: Untapped.gg API pubbliche, Quick Draft e Premier DFT, ultimi 90 giorni; scaricato il 03/11/2026 00:58; rigenerato da Companion/Drafter/quick_draft_untapped.py
---

# Il Quick Draft di DFT visto da Untapped

17Lands pubblica solo il Premier (umani); noi giochiamo il Quick (bot). Qui il formato vero.

## 1. Le coppie: Quick contro Premier

| Coppia | Quick: partite vinte | partite | Premier: posto | Premier: vinte |
| :--- | ---: | ---: | ---: | ---: |
| WG | **55.9%** | 3,809 | 1 | 54.9% |
| UB | **55.1%** | 6,173 | 7 | 53.6% |
| UG | **54.4%** | 3,759 | 3 | 54.6% |
| BR | **54.2%** | 4,871 | 8 | 53.4% |
| WU | **54.1%** | 4,777 | 10 | 50.6% |
| BG | **54.0%** | 4,373 | 4 | 54.4% |
| UR | **53.2%** | 5,550 | 6 | 53.7% |
| RG | **52.9%** | 2,446 | 5 | 53.8% |
| WB | **52.5%** | 2,908 | 2 | 54.9% |
| WR | **52.0%** | 3,946 | 9 | 52.4% |

Errore tipico su 2.000-5.000 partite: ±1-1,5 punti. La classifica del Premier non vale per il Quick, e nessuna delle due si usa come bonus sulle carte (regola permanente del 10 ott 2026): al massimo uno spareggio.

## 2. Come sono fatti i mazzi da 7 vittorie (557 con la lista, su 705 trofei)

Colori (3+ carte per colore): UB 71, BR 61, UR 59, WG 56, WU 46, BG 41, UG 39, WR 37, WB 34, RG 26

| Voce | Mediana | 10°-90° percentile | Modello del 9 ott |
| :--- | ---: | ---: | :--- |
| creature | **13.0** | 10.0-16.0 | 15-17 |
| creature da 1-2 | **6.0** | 3.0-9.0 | ≥5 (6-8) |
| creature da 5+ | **2.0** | 0.0-4.0 | ≤2 |
| costo medio creature | **3.0** | 2.5-3.6 | ≤2,9 |
| rimozioni vere | **3.0** | 1.0-6.0 | 5-7 |
| rimozioni grosse | **3.0** | 1.0-5.0 | ≥3 |
| stazza (forza 3+ o costituzione 4+) | **7.0** | 4.0-10.0 | ≥4 |
| pressione al T4 | **6.0** | 4.0-8.0 | ≥6 |
| altre (pescate, trucchi, planeswalker) | **6.0** | 4.0-10.0 | ≤3 |
| minacce (volanti 3+ o 5/5+) | **1.0** | 0.0-2.0 | ≥3 |
| terre | **17.0** | 16.0-17.0 | 16-17 |

**Contro-caso:** sono solo mazzi vincenti, senza i perdenti accanto. Dicono cosa basta per arrivare a 7 nel Quick, non cosa causa la vittoria. Il modello del 9 ott viene dal Premier di 6 set con i perdenti dentro.
