---
fonte: Untapped.gg API pubbliche, Quick Draft e Premier MSH, ultimi 90 giorni; scaricato il 05/11/2026 22:43; rigenerato da Companion/Drafter/quick_draft_untapped.py
---

# Il Quick Draft di MSH visto da Untapped

17Lands pubblica solo il Premier (umani); noi giochiamo il Quick (bot). Qui il formato vero.

## 1. Le coppie: Quick contro Premier

| Coppia | Quick: partite vinte | partite | Premier: posto | Premier: vinte |
| :--- | ---: | ---: | ---: | ---: |
| WU | **56.8%** | 31,569 | 1 | 56.2% |
| BG | **55.3%** | 12,919 | 4 | 54.3% |
| UG | **54.8%** | 10,592 | 2 | 54.6% |
| WG | **54.8%** | 14,165 | 3 | 54.4% |
| RG | **54.3%** | 7,565 | 5 | 53.1% |
| WR | **53.7%** | 8,926 | 6 | 53.0% |
| WB | **53.4%** | 10,379 | 7 | 52.9% |
| UR | **52.9%** | 9,747 | 9 | 51.4% |
| UB | **52.6%** | 14,518 | 8 | 52.1% |
| BR | **50.7%** | 12,907 | 10 | 50.9% |

Errore tipico su 2.000-5.000 partite: ±1-1,5 punti. La classifica del Premier non vale per il Quick, e nessuna delle due si usa come bonus sulle carte (regola permanente del 10 ott 2026): al massimo uno spareggio.

## 2. Come sono fatti i mazzi da 7 vittorie (776 con la lista, su 3046 trofei)

Colori (3+ carte per colore): WU 55, UR 47, BRG 45, UG 45, UB 44, BG 44, WUG 41, BR 40, WB 39, WRG 38

| Voce | Mediana | 10°-90° percentile | Modello del 9 ott |
| :--- | ---: | ---: | :--- |
| creature | **15.0** | 12.0-18.0 | 15-17 |
| creature da 1-2 | **5.0** | 3.0-7.0 | ≥5 (6-8) |
| creature da 5+ | **2.0** | 0.0-4.0 | ≤2 |
| costo medio creature | **3.1** | 2.7-3.5 | ≤2,9 |
| rimozioni vere | **3.0** | 1.0-6.0 | 5-7 |
| rimozioni grosse | **3.0** | 0.0-5.0 | ≥3 |
| stazza (forza 3+ o costituzione 4+) | **7.0** | 4.0-10.0 | ≥4 |
| pressione al T4 | **6.8** | 5.0-8.8 | ≥6 |
| altre (pescate, trucchi, planeswalker) | **5.0** | 2.0-9.0 | ≤3 |
| minacce (volanti 3+ o 5/5+) | **1.0** | 0.0-2.0 | ≥3 |
| terre | **17.0** | 16.0-17.0 | 16-17 |

**Contro-caso:** sono solo mazzi vincenti, senza i perdenti accanto. Dicono cosa basta per arrivare a 7 nel Quick, non cosa causa la vittoria. Il modello del 9 ott viene dal Premier di 6 set con i perdenti dentro.
