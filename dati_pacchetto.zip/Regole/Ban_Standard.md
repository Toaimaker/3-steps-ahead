# Carte bandite in Standard

Aggiornato: 2026-11-04 18:56 (fonte: Scryfall `banned:standard`)

- **Abuelo's Awakening** (LCI) {X}{3}{W} Sorcery
- **Badgermole Cub** (TLA) {1}{G} Creature — Badger Mole
- **Cori-Steel Cutter** (TDM) {1}{R} Artifact — Equipment
- **Gran-Gran** (TLA) {U} Legendary Creature — Human Peasant Ally
- **Heartfire Hero** (BLB) {R} Creature — Mouse Soldier
- **Hopeless Nightmare** (WOE) {B} Enchantment
- **Monstrous Rage** (WOE) {R} Instant
- **Proft's Eidetic Memory** (MKM) {1}{U} Legendary Enchantment
- **Screaming Nemesis** (DSK) {2}{R} Creature — Spirit
- **Stormchaser's Talent** (BLB) {U} Enchantment — Class
- **This Town Ain't Big Enough** (OTJ) {4}{U} Instant
- **Up the Beanstalk** (WOE) {1}{G} Enchantment
- **Vivi Ornitier** (FIN) {1}{U}{R} Legendary Creature — Wizard
