# Set legali in Standard

Aggiornato: 2026-11-04 18:56

Rotazione: la prossima è a **febbraio 2027** (via Wilds of Eldraine, Lost Caverns of Ixalan, Murders at Karlov Manor, Outlaws of Thunder Junction, Bloomburrow, Duskmourn). Nessuna rotazione nel 2026. Dal 2027 la rotazione segue la prima uscita premier dell'anno.

| Set | Codice | Uscita | Carte nel pool |
|:--|:--|:--|--:|
| Duel Decks: Knights vs. Dragons | DDG | 2011-04-01 | 1 |
| Welcome Deck 2017 | W17 | 2017-04-15 | 1 |
| Rivals of Ixalan | RIX | 2018-01-19 | 2 |
| Core Set 2019 | M19 | 2018-07-13 | 2 |
| Jumpstart | JMP | 2020-07-17 | 2 |
| Zendikar Rising | ZNR | 2020-09-25 | 1 |
| Adventures in the Forgotten Realms | AFR | 2021-07-23 | 1 |
| Phyrexia: All Will Be One | ONE | 2023-02-10 | 1 |
| March of the Machine | MOM | 2023-04-21 | 1 |
| Commander Masters | CMM | 2023-08-04 | 1 |
| Wilds of Eldraine | WOE | 2023-09-08 | 258 |
| The Lost Caverns of Ixalan Commander | LCC | 2023-11-17 | 1 |
| The Lost Caverns of Ixalan | LCI | 2023-11-17 | 273 |
| Murders at Karlov Manor | MKM | 2024-02-09 | 263 |
| The Big Score | BIG | 2024-04-19 | 29 |
| Outlaws of Thunder Junction | OTJ | 2024-04-19 | 264 |
| Bloomburrow | BLB | 2024-08-02 | 261 |
| Duskmourn: House of Horror | DSK | 2024-09-27 | 264 |
| Foundations | FDN | 2024-11-15 | 423 |
| Innistrad Remastered | INR | 2025-01-24 | 4 |
| Aetherdrift | DFT | 2025-02-14 | 259 |
| Tarkir: Dragonstorm Commander | TDC | 2025-04-11 | 13 |
| Tarkir: Dragonstorm | TDM | 2025-04-11 | 263 |
| Final Fantasy | FIN | 2025-06-13 | 305 |
| Edge of Eternities Commander | EOC | 2025-08-01 | 7 |
| Edge of Eternities | EOE | 2025-08-01 | 254 |
| Marvel's Spider-Man | SPM | 2025-09-26 | 134 |
| Spotlight Series | PSPL | 2025-10-24 | 1 |
| Avatar: The Last Airbender | TLA | 2025-11-21 | 278 |
| Avatar: The Last Airbender Eternal | TLE | 2025-11-21 | 5 |
| Lorwyn Eclipsed Commander | ECC | 2026-01-23 | 7 |
| Lorwyn Eclipsed | ECL | 2026-01-23 | 262 |
| Teenage Mutant Ninja Turtles Eternal | TMC | 2026-03-06 | 1 |
| Teenage Mutant Ninja Turtles | TMT | 2026-03-06 | 188 |
| Secrets of Strixhaven Commander | SOC | 2026-04-24 | 22 |
| Secrets of Strixhaven | SOS | 2026-04-24 | 264 |
| Marvel Super Heroes Commander | MSC | 2026-06-26 | 63 |
| Marvel Super Heroes | MSH | 2026-06-26 | 272 |
| The Hobbit | HOB | 2026-08-14 | 188 |
| The Hobbit Eternal | HOC | 2026-08-14 | 4 |
| Reality Fracture | FRA | 2026-10-02 | 279 |
| Reality Fracture Commander | FRC | 2026-10-02 | 5 |
| Star Trek Commander | TRC | 2026-11-13 | 22 |
| Star Trek | TRK | 2026-11-13 | 10 |
| Marvel: Darkhold Destiny | MDD | 2027-04-09 | 5 |
